G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-03-03T12:58:36+01:00*
G04 #@! TF.ProjectId,Display panel,44697370-6c61-4792-9070-616e656c2e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-03-03 12:58:36*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,6.400000*%
%ADD11R,2.000000X2.000000*%
%ADD12C,2.000000*%
%ADD13R,2.000000X3.200000*%
%ADD14RoundRect,0.250000X0.600000X-0.600000X0.600000X0.600000X-0.600000X0.600000X-0.600000X-0.600000X0*%
%ADD15C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X105000000Y-51000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,SW2*
X100500000Y-72500000D03*
D12*
X105500000Y-72500000D03*
X103000000Y-72500000D03*
D13*
X97400000Y-65000000D03*
X108600000Y-65000000D03*
D12*
X105500000Y-58000000D03*
X100500000Y-58000000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,H2*
X105000000Y-79000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J2*
X84350000Y-53270000D03*
D15*
X84350000Y-50730000D03*
X81810000Y-53270000D03*
X81810000Y-50730000D03*
X79270000Y-53270000D03*
X79270000Y-50730000D03*
X76730000Y-53270000D03*
X76730000Y-50730000D03*
X74190000Y-53270000D03*
X74190000Y-50730000D03*
X71650000Y-53270000D03*
X71650000Y-50730000D03*
G04 #@! TD*
M02*
